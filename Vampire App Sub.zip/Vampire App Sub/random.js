function display_chosen_option() {

var random_boolean = Math.random() < 0.5;

console.log(Math.random() < 0.5);


// call the function
display_chosen_option();