function check() {
	var c=0;
	var q1=document.quiz.question1.value;
	var q2=document.quiz.question2.value;
	var q3=document.quiz.question3.value;
	var q4=document.quiz.question4.value;
	var result=document.getElementById('result');
	var quiz=document.getElementById("quiz");
	if (q1=="No"){c+= 4}
	if (q2=="Yes"){c+= 3}
	if (q3=="No"){c+= 3}
	if (q4=="Yes"){c+= 1}
	/*result.textContent=`${c}`;
	/*document.write(c);*/
	
	quiz.style.display="none";
	
	if(c>=7){
		result.textContent='Your Classmate is a Vampire!'
	}
	else {
		result.textContent='Your Classmate is Human.'
	}
}